# Muslim Graphics — Android App (WebView Wrapper)

**Package name:** `com.muslimgraphics.app`
**App loads:** https://muslimgraphics.vercel.app (apnar deploy kora website)

## যা যা আছে
- পুরো Android Studio প্রজেক্ট (Java, WebView-ভিত্তিক)
- File upload (ছবি আপলোড), file download (কেনা গ্রাফিক্স ডাউনলোড), external link handling (mailto/tel/tawk.to chat), back button navigation, pull-to-refresh
- App icon আপনার `logo.jpg` থেকে বানানো

## কিভাবে APK বানাবেন

1. **Android Studio** ইন্সটল করুন (না থাকলে): https://developer.android.com/studio
2. এই পুরো `MuslimGraphicsApp` ফোল্ডারটা **Open** করুন Android Studio দিয়ে (File → Open)।
3. প্রথমবার খুললে Android Studio নিজে থেকেই Gradle wrapper ও দরকারি SDK/tools ডাউনলোড করে নেবে (ইন্টারনেট লাগবে) — একটু সময় লাগতে পারে, "Sync Now" চাপুন যদি জিজ্ঞেস করে।
4. উপরের মেনু থেকে: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. Build শেষ হলে নিচে ডান কোণায় "locate" লিংক আসবে — সেখানে ক্লিক করলে `app-debug.apk` ফাইলটা পাবেন।
   - সাধারণত থাকে: `app/build/outputs/apk/debug/app-debug.apk`

এই debug APK দিয়েই টেস্ট করতে পারবেন (নিজের ফোনে ইন্সটল, বা টিমকে দেওয়ার জন্য)।

## Play Store-এ দিতে চাইলে (Release/Signed APK)

Debug APK দিয়ে Play Store-এ আপলোড করা যায় না। Release বানাতে:

1. **Build → Generate Signed Bundle / APK** সিলেক্ট করুন
2. **APK** (বা Play Store-এর জন্য **Android App Bundle**) সিলেক্ট করে Next
3. "Create new..." চেপে একটা keystore বানান (একটা পাসওয়ার্ড ও কিছু তথ্য দিতে হবে — **এই keystore ফাইল ও পাসওয়ার্ড নিরাপদে সংরক্ষণ করুন**, ভবিষ্যতে app আপডেট দিতে এইটাই লাগবে, হারালে নতুন app হিসেবে দিতে হবে)
4. **release** বিল্ড ভ্যারিয়েন্ট সিলেক্ট করে Finish — signed APK/AAB রেডি হয়ে যাবে

## যদি ওয়েবসাইটে কোনো পরিবর্তন আনতে চান
App সরাসরি লাইভ ওয়েবসাইট (`https://muslimgraphics.vercel.app`) লোড করে, তাই **কোনো ওয়েবসাইট কনটেন্ট বদলালে app-এ ঠিক তখনই দেখা যাবে** — নতুন করে APK বানানোর দরকার নেই, শুধু Vercel-এ redeploy করলেই হবে।

## App icon বদলাতে চাইলে
`app/src/main/res/mipmap-*/ic_launcher.png` ফাইলগুলো রিপ্লেস করুন (mdpi=48px, hdpi=72px, xhdpi=96px, xxhdpi=144px, xxxhdpi=192px)।

## Domain/URL বদলাতে চাইলে
`app/src/main/java/com/muslimgraphics/app/MainActivity.java` ফাইলে উপরের দিকে থাকা `SITE_URL` ও `SITE_HOST` ভ্যারিয়েবল দুটো বদলে দিন।
