package com.muslimgraphics.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.View;

/**
 * Simple WebView wrapper for https://muslimgraphics.vercel.app
 * Handles: JS/DOM storage (site uses localStorage + IndexedDB),
 * file uploads (camera/gallery), file downloads (purchased graphics),
 * external links (mailto/tel/tawk.to chat), back navigation, pull-to-refresh.
 */
public class MainActivity extends AppCompatActivity {

    private static final String SITE_URL = "https://muslimgraphics.vercel.app";
    private static final String SITE_HOST = "muslimgraphics.vercel.app";

    private WebView webView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private View navProductsBtn;
    private View navCartBtn;
    private View navProfileBtn;
    private View navHomeFab;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int PERMISSION_REQUEST_CODE = 2001;
    private boolean pageReady = false;

    // These call functions that already exist in the site's own JavaScript,
    // so tapping a tab behaves exactly like tapping the matching button on
    // the website itself (closes any open cart/modal first, then acts).
    private static final String JS_GO_HOME =
            "(function(){"
            + "if (typeof goToShop === 'function') { goToShop(); }"
            + "else { window.scrollTo({top:0,behavior:'smooth'}); }"
            + "})();";

    private static final String JS_GO_PRODUCTS =
            "(function(){"
            + "if (typeof goToShop === 'function') { goToShop(); }"
            + "setTimeout(function(){"
            + "  if (typeof goToCatalog === 'function') { goToCatalog(); }"
            + "}, 150);"
            + "})();";

    private static final String JS_GO_CART =
            "(function(){ if(typeof openCart==='function'){ openCart(); } })();";

    private static final String JS_GO_PROFILE =
            "(function(){"
            + "try{if(typeof closeCart==='function')closeCart();}catch(e){}"
            + "if (typeof currentUser!=='undefined' && currentUser) {"
            + "  if (typeof openEditProfileModal==='function') { openEditProfileModal(); }"
            + "} else {"
            + "  if (typeof openAuthModal==='function') { openAuthModal('signin'); }"
            + "}"
            + "})();";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        swipeRefreshLayout = findViewById(R.id.swipe_refresh);
        navProductsBtn = findViewById(R.id.nav_products_btn);
        navCartBtn = findViewById(R.id.nav_cart_btn);
        navProfileBtn = findViewById(R.id.nav_profile_btn);
        navHomeFab = findViewById(R.id.nav_home_fab);

        setupWebView();
        setupBottomNav();
        requestNeededPermissions();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(SITE_URL);
        }
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                String host = uri.getHost();

                if ("tel".equals(scheme) || "mailto".equals(scheme)) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                // Keep navigation on our own domain inside the WebView;
                // send anything else (support chat, external links) to the browser.
                if (host != null && host.contains(SITE_HOST)) {
                    return false;
                }
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                swipeRefreshLayout.setRefreshing(false);
                pageReady = true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Do not bypass SSL errors.
                handler.cancel();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                              FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "ফাইল বাছাই করা যায়নি", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                         String mimeType, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimeType);
                    request.addRequestHeader("cookie", CookieManager.getInstance().getCookie(url));
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    String fileName = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(MainActivity.this, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e("MainActivity", "Download failed", e);
                    Toast.makeText(MainActivity.this, "ডাউনলোড ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show();
                }
            }
        });

        swipeRefreshLayout.setOnRefreshListener(() -> webView.reload());
    }

    private void setupBottomNav() {
        navHomeFab.setOnClickListener(v -> runNavJs(JS_GO_HOME));
        navProductsBtn.setOnClickListener(v -> runNavJs(JS_GO_PRODUCTS));
        navCartBtn.setOnClickListener(v -> runNavJs(JS_GO_CART));
        navProfileBtn.setOnClickListener(v -> runNavJs(JS_GO_PROFILE));
    }

    private void runNavJs(String js) {
        if (!pageReady) {
            // Site scripts haven't loaded yet; ignore taps until onPageFinished.
            return;
        }
        webView.evaluateJavascript(js, null);
    }

    private void requestNeededPermissions() {
        String[] perms = {Manifest.permission.CAMERA};
        boolean needed = false;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed = true;
            }
        }
        if (needed) {
            ActivityCompat.requestPermissions(this, perms, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                } else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }
}
